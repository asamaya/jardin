-- Script para crear la base de datos ----> bdretardados		              
-- Autor. Sergio Capacho              
-- Fecha de última actualización: Lunes 11/Mayo/2026 - 11:42 Pm   

-- Abrir_Postgres_desde_consola
-- 1.- Cmd
-- 2.- C:\...> psql --version
-- 3.- C:\...> chcp 1252
--	Esto de hace para evitar que se genere una advertencia  
--	por codificación en la consola (850)
-- 4.- C:\....>  psql -h localhost -U username/postgres -d Name_BD/BDRetardados  -p port
-- postgres=# SELECT version();


\! cls
\echo ' '
\echo ' '
\echo '============================================================'
\echo '     Bienvenido al Script para construir  BDRETARDADOS      '
\echo '  Autor: Sergio Capacho - Miércoles 29/Abril/2026 - 03:27 Pm  '
\echo '============================================================'
-- SELECT ' '  AS paso, pg_sleep(10);





-----------------------------------------------------------------------------
--  01.- BLOQUE PARA CREAR BDRETARDADOS
-----------------------------------------------------------------------------
\echo ' '
\echo ' '
\echo ' '
\echo ' '
\echo 'Paso 01: BLOQUE PARA CREAR BDRETARDADOS    '
-- SELECT ' '  AS paso, pg_sleep(05);



\echo ' '
\echo ' '
\echo 'Paso 01.01: Conectando a la BD postgres .....'
-- SELECT ' '  AS paso, pg_sleep(02);
\c postgres

 

\echo ' '
\echo ' '
\echo 'Paso 01.02: Listando las BDs Actuales de postgres.....'
-- SELECT ' '  AS paso, pg_sleep(02);
-- \l (ele minúscula)---> Muestra todas las BDs 
SELECT datname AS "Base de Datos" FROM pg_database ORDER BY datname;



\echo ' '
\echo ' '
\echo 'Paso 01.03: Eliminando  BDretardados si Existe .....'
-- SELECT ' '  AS paso, pg_sleep(02);
DROP DATABASE IF EXISTS bdretardados;



\echo ' '
\echo ' '
\echo 'Paso 01.04: Listando las BDs de postgres.....'
-- SELECT ' '  AS paso, pg_sleep(02);
-- \l (ele minúscula)---> Muestra todas las BDs 
SELECT datname AS "Base de Datos" FROM pg_database ORDER BY datname;



\echo ' '
\echo ' '
\echo 'Paso 01.05: Creando BDretardados .....'
-- SELECT ' '  AS paso, pg_sleep(02);
CREATE DATABASE  bdretardados with ENCODING='UTF8';

/*
CREATE DATABASE bdretardados
       OWNER = postgres
       ENCODING = 'UTF8'
       TABLESPACE = pg_default
       LC_COLLATE = 'Spanish_Colombia.1252'
       LC_CTYPE = 'Spanish_Colombia.1252'
       CONNECTION LIMIT = -1;
*/



\echo ' '
\echo ' '
\echo 'Paso 01.06: Listando las BDs de postgres.....'
-- SELECT ' '  AS paso, pg_sleep(02);
-- \l (ele minúscula)---> Muestra todas las BDs 
SELECT datname AS "Base de Datos" FROM pg_database ORDER BY datname;



\echo ' '
\echo ' '
\echo 'Paso 01.07: Conectando con  bdretardados .....'
-- SELECT ' '  AS paso, pg_sleep(02);
\c bdretardados





----------------------------------------------------------------------------
-- 02.- BLOQUE DE CREACIÓN DE TABLAS
----------------------------------------------------------------------------
\echo ' '
\echo ' '
\echo ' '
\echo ' '
\echo 'Paso 02: BLOQUE CREAR TABLAS    '
-- SELECT ' '  AS paso, pg_sleep(05);



-- TMSTATUS
\echo ' '
\echo ' '
\echo 'Paso 02.01: Creando TMSTATUS .....................'
-- SELECT ' '  AS paso, pg_sleep(02);
CREATE  TABLE  tmstatus(
	pkcods	 SERIAL	  not null      primary key  ,
	dstatus varchar(50)    UNIQUE not null) ;

INSERT    INTO   tmstatus  (pkcods,dstatus)  VALUES  (0,  'ELIMINADO'); 
INSERT    INTO   tmstatus  (pkcods,dstatus)  VALUES  (1,  'ACTIVO'); 

SELECT  *   FROM  tmstatus ;     

\d tmstatus
--INSERTAR DATOS EN CAMPOS SERIALES QUE INICIAN EN CERO
--OPCIÓN 1: Modificar la estructura del campo secuencia (tmstatus_pkcods_seq)
--          de la tabla tmstatus con el comando ALTER TABLE
--          El número 2 indica que el siguiente valor a insertar es el 3
--       ALTER SEQUENCE mi_tabla_id_seq RESTART WITH 2;
--       Ejemplo: ALTER SEQUENCE tmstatus_pkcods_seq RESTART WITH 2;

ALTER SEQUENCE  public.tmstatus_pkcods_seq RESTART WITH 2;

--OPCION 2: para continuar insertando registros en el campo pkcods
--      se debe usar  nextval('tmstatus_pkcods_seq'::regclass)
--      eso se debe usar pues mis registros los estoy iniciando en 0
--Desglose técnico
--nextval(...): Es una función de PostgreSQL que le pide a una secuencia 
--    que "salte" al siguiente número disponible y lo devuelva. 
--    Cada vez que se llama, el contador interno de la secuencia aumenta (SERIAL).
--'tmstatus_pkcods_seq': Este es el nombre del objeto Sequence (secuencia) 
--    en tu base de datos. Es un contador independiente que lleva el registro 
--    de por qué número va la cuenta (por ejemplo: 1, 2, 3...)
-- ::regclass: Es un "cast" o conversión de tipo. 
--    Le dice a PostgreSQL que trate esa cadena de texto no solo como palabras, 
--    sino como un identificador de un objeto real del sistema 
--    (en este caso, una clase de registro que representa a la secuencia).
--    La otra forma CAST('tmstatus_pkcods_seq' AS regclass)
--Ejemplo: 
--    insert into tmstatus(pkcods, dstatus) values (nextval('tmstatus_pkcods_seq'::regclass), 'Nueva Solicitud');
--    insert into tmstatus(pkcods, dstatus) values (CAST('tmstatus_pkcods_seq' AS regclass), 'Nueva Solicitud');
--OJO OJO: Si el campo SERIAL INICIA EN UNO(1), ESTO NO ES NECESARIO.

 


-- TMCARGOS
\echo ' '
\echo ' '
\echo 'Paso 02.02: Creando TMCARGOS ......................'
-- SELECT ' '  AS paso, pg_sleep(02);
CREATE   TABLE    tmcargos(
	pkcodcar SERIAL primary key  not null,
	dcargo	  varchar(30) 	 not null UNIQUE,
	sueldo	  decimal(12,2)  	 not null,
	fkcods	  INTEGER	 	 not null DEFAULT 1,
	foreign  key(fkcods)  references  tmstatus(pkcods)  
			on  update  cascade  on  delete    restrict );

INSERT    INTO  tmcargos (dcargo,	sueldo, fkcods)	   VALUES	
		('PRESIDENTE' ,	 5000000.01, 1) ,
		('VICE PRESIDENTE',	 4500000.02, 0) ,
		('GERENTE' ,		 4000000.03, 1), 
		('SUB-GERENTE' ,  	 3500000.04, 0) ,
		('COORDINADOR',	 3000000.05, 1),
		('SUPERVISOR', 	 2500000.06, 0);  

SELECT    *    FROM    tmcargos ; 

SELECT pkcodcar, 
	dcargo, 
	to_char( sueldo, '999G999G999D99' ) As "Sueldo"
FROM tmcargos; 

SELECT TO_CHAR(SUM(sueldo), '999G999G999D99') AS "Sumatoria Sueldos"
FROM tmcargos;

SELECT TO_CHAR(MIN(sueldo), '999G999G999D99') AS "Sueldo Mínimo"
FROM tmcargos;

SELECT TO_CHAR(MAX(sueldo), '999G999G999D99') AS "Sueldo Máximo"
FROM tmcargos;

SELECT TO_CHAR(AVG(sueldo), '999G999G999D99') AS "Sueldo promedio"
FROM tmcargos;

SELECT TO_CHAR(  
			( 
				(SELECT SUM(sueldo) from tmcargos) 
					/ 
				(SELECT COUNT(sueldo) from tmcargos)
			), 
		'999G999G999D99'
	) AS "Sueldo Promedio";



-- TMEMPLEADOS
\echo ' '
\echo ' '
\echo 'Paso 02.03: Creando TMEMPLEADOS .....................'
-- SELECT ' '  AS paso, pg_sleep(02);
CREATE  TABLE   tmempleados (
		pkcedemple	 varchar(12) 	not null PRIMARY KEY,
		nomemple	 varchar(40)  not null,
		fecha 		 date 		not null,
		fkcodcar	 integer 	not null,
		fkcods		 integer 	not null DEFAULT 1,
		foreign  key(fkcodcar)  references  tmcargos(pkcodcar) 
			on  update  cascade    on  delete  restrict,
		foreign  key(fkcods)  references  tmstatus(pkcods) 
			on  update  cascade    on  delete  restrict) ;


INSERT	  INTO  tmempleados (pkcedemple,	nomemple,   fecha,	fkcodcar)  VALUES 
		('1000' , 'ROBERTO JAIMES' , '1978-03-03' , 3),
		('2000' , 'ZILA CONTRERAS' , '1980-10-05' , 2),
		('3000' , 'MARTHA' 	      , '1996-11-22' , 3),
		('4000' , 'CARLOS'         , '2000-07-15' , 4),
		('5000' , 'MATIAS'         , '2005-09-25' , 4),
		('6000' , 'NATASHA'	      , '2007-10-28' , 1),
		('7000' , 'PEGGY CARTER'   , '1999-08-29' , 2),
		('8000' , 'YSA CAPACHO'    , '1993-07-23' , 2),
		('9000' , 'MARIA MORALES'  , '2003-07-07' , 4);

SELECT    *    FROM    tmempleados ;  


INSERT	  INTO  tmempleados (pkcedemple,	nomemple,   fecha,	fkcodcar)  VALUES 
		('17',	'VALERIA', 			'1981-04-07' , 3),
		('13', 'ANGELY', 			'1978-06-21' , 2),
		('7', 	'SERGIO CAPACHO', 		'1967-11-22' , 3),
		('4020','YSAURA', 			'2018-02-05' , 4),
		('4017','MESSI', 			'1996-06-09' , 4),
		('4011','RONALDO', 			'2011-12-25' , 1),
		('9057','CARMENZA', 			'1988-08-09' , 2),
		('9026','FANNY', 			'2005-07-10' , 2),
		('10000','MERCY', 			'2013-07-07' , 4);


SELECT   *   FROM   tmempleados   ORDER BY    CAST (pkcedemple  AS  BIGINT)    ;
SELECT   *   FROM   tmempleados   ORDER BY    pkcedemple  ::  BIGINT    ;


SELECT NOW() AS "Fecha Actual";
SELECT NOW() AS xfecha;



SELECT  pkcedemple, nomemple, fecha As "FeNac",
		EXTRACT( YEAR FROM Now())   As "Año Actual",
		(EXTRACT( YEAR FROM Now())  -  (EXTRACT( YEAR FROM fecha))) As Edad
FROM     Tmempleados  
ORDER BY    Edad, CAST (pkcedemple  AS  BIGINT) ;



-- TMEXCUSAS
\echo ' '
\echo ' '
\echo 'Paso 02.04: Creando TMEXCUSAS .....................'
-- SELECT ' '  AS paso, pg_sleep(02);
CREATE    TABLE    tmexcusas(
	pkcodexcu	 SERIAL	  not null	 primary key ,
	dexcusa	 varchar(30)	  not null     UNIQUE ,
	fkcods   	 INTEGER 	  not null	 DEFAULT 1 ,
	foreign  key(fkcods)  references  tmstatus(pkcods) 
			on  update  cascade  on  delete  restrict)  ;

INSERT	  INTO    tmexcusas(pkcodexcu, dexcusa)    VALUES
	(0, '---------------------------' ),	 
 	(1, 'ME QUEDE DORMIDO' ),
	(2, 'SALI TARDE DE LA CASA'),
	(3, 'NO ME BUSCARON'),
	(4, 'PELIE CON EL AGUILA'),
	(5, 'MUCHA LLUVIA'),
	(6, 'MUCHO TRAFICO'),
	(7, 'EL CARRO NO ME QUIERE'),
 	(8, 'ME SECUESTRARON') ;

SELECT    *    FROM    tmexcusas ;  

-- Nota: Esro lo hago pues la clave primaria la inice en 0
-- El número 8 indica que el siguiente valor a insertar es el 9
ALTER SEQUENCE  public.tmexcusas_pkcodexcu_seq RESTART WITH 8;


-- TMUSUARIOS
\echo ' '
\echo ' '
\echo 'Paso 02.05: Crear TMUSUARIOS .....................'
-- SELECT ' '  AS paso, pg_sleep(02);
CREATE TABLE  tmusuarios (
	pknu		SERIAL 	not null   primary key,
	email_u 	varchar(70)	not null   UNIQUE,
	clave_u	varchar(40)	not null,
	nom_u 		varchar(40)	not null,
	foto_u		varchar(40)	not null,
	nivel_u	integer	not null, 
	fkcods   	INTEGER 	not null	DEFAULT 1  ,
	foreign key(fkcods) references tmstatus(pkcods) 
		on update cascade on delete restrict  ) ;

/* NIVELES DE USUARIO   */	
/* 0--> Usuario suspendido   */	
/* 1--> Solo acceso al Módulo Maestros   */
/* 2--> Solo acceso al Módulo Procesos   */
/* 3--> Solo acceso al Módulo Reportes   */
/* 4--> Acceso total a todos los módulos */


INSERT  INTO  tmusuarios (email_u,   clave_u,   nom_u,   foto_u, nivel_u)  VALUES
('WILFREDO@SYSTEMCAP.NET',	1234,   'WILCONSA',	'foto00.jpg',   0),
('YSA@SYSTEMCAP.NET',  	1234,   'YSA',   	'foto00.jpg',   1),
('GREISY@SYSTEMCAP.NET',  	1234,   'GREISY',   	'foto00.jpg',   2),
('ZILA@SYSTEMCAP.NET',  	1234,   'ZILA',   	'foto00.jpg',   3),
('SERGIO@SYSTEMCAP.NET',  	1234,   'SERGIO',   	'foto00.jpg',   4); 

SELECT  *  FROM  TMUSUARIOS;  



-- TDRETARDOS
\echo ' '
\echo ' '
\echo 'Paso 02.06: Creando TDRETARDOS .....................'
-- SELECT ' '  AS paso, pg_sleep(06);
CREATE   TABLE  tdretardos(
	pknr	  	SERIAL		not null PRIMARY KEY,
	fkcedemple	varchar(12) 	not null,
	fkcodexcu	integer 	not null,
	fecha	  	date 		not null,
	hora	  	time 		not null,
	fkcods	  	integer 	not null DEFAULT 1,
	foreign  key(fkcedemple)  references  tmempleados(pkcedemple)  
			on  update  cascade  on  delete  restrict,
	foreign  key(fkcodexcu) references  tmexcusas(pkcodexcu) 
			on  update  cascade  on  delete restrict,
	foreign  key(fkcods)	 references tmstatus(pkcods) 
			on  update  cascade  on  delete restrict);
	
	
INSERT	  INTO   tdretardos  (fkcedemple,	fkcodexcu,	fecha,	hora)   VALUES 
	('2000', 3,	'2022-04-05',	'08:32:00'),
	('5000', 3,	'2022-04-05',	'08:50:00'),
	('4000', 1,	'2022-04-06',	'09:09:00'),
	('3000', 5,	'2022-04-06',	'09:13:00'),
	('6000', 7,	'2022-04-11',	'08:21:00'),
	('1000', 2,	'2022-04-14',	'08:16:00'),
	('2000', 6,	'2022-04-17',	'10:00:00'),
	('3000', 7,	'2022-04-19',	'08:11:00'),
	('2000', 3,	'2022-04-21',	'08:13:00'),
	('1000', 8,	'2022-04-21',	'08:15:00'),
	('5000', 2,	'2022-04-21',	'08:20:00'),
	('2000', 6,	'2022-04-23',	'08:27:00'),
	('3000', 4,	'2022-04-23',	'03:30:00'),
	('4000', 2,	'2022-04-23',	'08:45:00'),
	('6000', 5,	'2022-04-25',	'08:05:00'),
	('2000', 4,	'2022-04-25',	'08:32:00'),
	('4000', 1,	'2022-04-27',	'09:00:00'),
	('6000', 7,	'2022-04-28',	'09:00:00'),



	('1000', 1,	'2022-01-07',	'10:43:00'),
	('3000', 3,	'2022-01-07',	'10:50:00'),
	('4000', 7,	'2022-01-10',	'09:00:00'),
	('5000', 5,	'2022-01-12',	'08:20:00'),
	('6000', 6,	'2022-01-15',	'09:14:00'),


	('3000', 2,	'2022-05-01',	'08:40:00'),
	('2000', 8,	'2022-05-03',	'08:20:00'),
	('7000', 1,	'2022-05-05',	'09:00:00'),
	('6000', 3,	'2022-05-07',	'08:20:00'),
	('1000', 8,	'2022-05-13',	'08:17:00'),
	('4000', 2,	'2022-05-15',	'08:23:00'),
	('1000', 6,	'2022-05-16',	'09:05:00'),
	('3000', 7,	'2022-05-19',	'09:14:00'),
	('4000', 2,	'2022-05-26',	'08:17:00'),
	('4000', 5,	'2022-05-27',	'08:20:00'),
	('6000', 6,	'2022-05-27',	'08:22:00'),



	('3000', 3,	'2022-02-01',	'08:40:00'),
	('2000', 8,	'2022-02-03',	'08:20:00'),
	('5000', 6,	'2022-02-01',	'09:00:00'),
	('6000', 3,	'2022-02-07',	'08:20:00'),
	('1000', 1,	'2022-02-13',	'08:17:00'),
	('4000', 2,	'2022-02-15',	'08:23:00'),
	('1000', 5,	'2022-02-16',	'09:05:00'),
	('3000', 7,	'2022-02-19',	'09:14:00'),
	('4000', 5,	'2022-02-26',	'08:17:00'),
	('4000', 3,	'2022-02-27',	'08:20:00'),
	('6000', 6,	'2022-02-27',	'08:22:00'),


	('2000',	4,	'2022-03-05',	'08:32:00'),
	('5000',	6,	'2022-03-05',	'08:50:00'),
	('4000',	7,	'2022-03-06',	'09:09:00'),
	('3000',	3,	'2022-03-06',	'09:13:00'),
	('6000',	7,	'2022-03-11',	'08:21:00'),
	('1000',	3,	'2022-03-14',	'08:16:00'),
	('2000',	6,	'2022-03-17',	'10:00:00'),
	('3000',	5,	'2022-03-19',	'08:11:00'),
	('5000',	2,	'2022-03-21',	'08:20:00'),
	('2000',	6,	'2022-03-23',	'08:27:00'),
	('3000',	5,	'2022-03-23',	'03:30:00'),
	('4000',	7,	'2022-03-23',	'08:45:00'),
	('6000',	5,	'2022-03-25',	'08:05:00'),
	('2000',	3,	'2022-03-25',	'08:32:00'),
	('4000',	6,	'2022-03-26',	'09:00:00'),
	('6000',	5,	'2022-03-28',	'09:00:00') ,


		
	('6000',	4,	'2022-01-05',	'08:32:00'),
	('3000',	6,	'2022-01-05',	'08:40:00'),
	('2000',	7,	'2022-01-06',	'09:00:00'),
	('3000',	3,	'2022-01-06',	'09:10:00'),
	('5000',	7,	'2022-01-11',	'08:17:00'),		
	('7000',	3,	'2022-01-14',	'08:32:00'),
	('3000',	6,	'2022-01-17',	'09:47:00'),
	('6000',	2,	'2022-01-21',	'08:24:00'),
	('4000',	6,	'2022-01-23',	'08:37:00'),
	('3000',	5,	'2022-01-23',	'03:20:00'),
	('2000',	7,	'2022-01-23',	'08:15:00'),
	('1000',	5,	'2022-01-25',	'08:35:00'),
	('6000',	3,	'2022-01-25',	'08:38:00'),
	('4000',	6,	'2022-01-27',	'09:00:00'),



	('3000',	2,	'2022-06-01',	'08:40:00'),
	('2000',	8,	'2022-06-03',	'08:20:00'),
	('7000',	1,	'2022-06-05',	'09:00:00'),
	('6000',	3,	'2022-06-07',	'08:20:00'),
	('1000',	8,	'2022-06-13',	'08:17:00'),
	('4000',	2,	'2022-06-15',	'08:23:00'),
	('1000',	6,	'2022-06-16',	'09:05:00'),
	('3000',	7,	'2022-06-19',	'09:14:00'),
	('4000',	2,	'2022-06-26',	'08:17:00'),
	('4000',	5,	'2022-06-27',	'08:20:00'),
	('6000',	6,	'2022-06-27',	'08:22:00'),
	('6000',	6,	'2022-06-27',	'08:22:00'),


			
	('1000',	2,	'2022-07-01',	'08:40:00'),
	('4000',	8,	'2022-07-03',	'08:20:00'),
	('7000',	1,	'2022-07-05',	'09:00:00'),
	('5000',	3,	'2022-07-07',	'08:20:00'),
	('3000',	8,	'2022-07-13',	'08:17:00'),
	('2000',	2,	'2022-07-15',	'08:23:00'),
			

	('6000',	6,	'2022-07-16',	'09:05:00'),
	('1000',	7,	'2022-07-19',	'09:14:00'),
	('6000',	2,	'2022-07-26',	'08:17:00'),
	('7000',	5,	'2022-11-27',	'08:20:00'),
	('3000',	6,	'2022-07-27',	'08:22:00') ,


	('1000',	1,	'2022-01-01',	'08:20:00'),
	('4000',	3,	'2022-02-03',	'08:35:00'),
	('7000',	7,	'2022-03-05',	'09:11:00'),
	('5000',	6,	'2022-04-07',	'08:21:00'),
	('3000',	2,	'2022-05-13',	'08:17:00'),
	('2000',	8,	'2022-06-15',	'08:12:00'),
	('6000',	4,	'2022-07-16',	'09:15:00'),
	('1000',	6,	'2022-08-19',	'09:19:00'),
	('6000',	7,	'2022-09-26',	'08:37:00'),
	('7000',	4,	'2022-10-27',	'08:25:00'),
	('3000',	6,	'2021-11-22',	'08:41:00'), 
	
	
	
	('1000',	1,	'2022-11-01',	'08:20:00'),
	('4000',	3,	'2022-11-03',	'08:35:00'),
	('6000',	7,	'2022-11-05',	'09:11:00'),
	('5000',	6,	'2022-11-07',	'08:21:00'),
	('3000',	2,	'2022-11-13',	'08:17:00'),
	('2000',	8,	'2022-11-15',	'08:12:00'),
	('7000',	4,	'2022-11-10',	'08:27:00'),
	('6000',	4,	'2022-11-16',	'09:15:00'),
	('1000',	6,	'2022-11-19',	'09:19:00'),
	('6000',	3,	'2022-11-12',	'08:40:00'),	
	('6000',	7,	'2022-11-26',	'08:37:00'),
	('6000',	4,	'2022-11-27',	'08:25:00'),
	('3000',	6,	'2021-11-22',	'08:41:00'),
	('6000',	6,	'2022-11-03',	'09:05:00'),
	('6000',	1,	'2022-11-19',	'09:05:00'),

	('1000',	1,	'2022-11-01',	'14:20:00'),
	('4000',	3,	'2022-11-03',	'15:35:00'),
	('6000',	7,	'2022-11-05',	'16:11:00'),
	('5000',	6,	'2022-11-07',	'14:21:00'),
	('3000',	2,	'2022-11-13',	'15:17:00'),
	('2000',	8,	'2022-11-15',	'15:12:00'),
	('7000',	4,	'2022-11-10',	'16:27:00'),
	('6000',	4,	'2022-11-16',	'17:15:00'),
	('1000',	6,	'2022-11-19',	'14:19:00'),
	('6000',	3,	'2022-11-12',	'08:40:00'),	
	('6000',	7,	'2022-11-26',	'08:37:00');


SELECT    *    FROM    tdretardos ;  

SELECT COUNT(pknr) AS "Total de Registros" FROM tdretardos ;




----------------------------------------------------------------------------
-- 03.- BLOQUE CONSULTAS
----------------------------------------------------------------------------
\echo ' '
\echo ' '
\echo ' '
\echo ' '
\echo 'Paso 03: BLOQUE CONSULTAS    '
-- SELECT ' '  AS paso, pg_sleep(05);



\echo ' '
\echo ' '
\echo 'Paso 03.01: Consultas simples y ordenadas .........................'
-- SELECT ' '  AS paso, pg_sleep(02);
SELECT pknr, 
	fkcedemple, 
	nomemple,
	fkcodexcu, 
	dexcusa, 
	Y.fecha, 
	Y.hora
FROM  tmempleados AS M, tdretardos AS Y, tmexcusas AS T
WHERE  ( Y.fkcedemple='6000'  and  M.pkcedemple='6000' ) 
		and  Y.fkcodexcu = T.pkcodexcu  
			and  (Y.fecha >= '2022-11-01' and  Y.fecha <= '2022-11-30') 
ORDER  BY  Y.fecha DESC;


SELECT Y.pknr, 
	Y.fkcedemple, 
	M.nomemple,
	Y.fkcodexcu, 
	T.dexcusa, 
	Y.fecha, 
	Y.hora
FROM  tmempleados AS M, tdretardos AS Y, tmexcusas AS T
WHERE  ( Y.fkcedemple='6000'  and  M.pkcedemple='6000' ) 
		and  Y.fkcodexcu = T.pkcodexcu  
			and  (Y.fecha >= '2022-11-01' and  Y.fecha <= '2022-11-30') 
ORDER  BY  Y.fecha DESC;


SELECT pknr,   
	fkcedemple AS "Cédula",   
	nomemple AS "Nombre",
	fkcodexcu AS "Código", 
	dexcusa, 
	tdretardos.fecha, 
	tdretardos.hora
FROM  tdretardos , tmempleados ,  tmexcusas   
WHERE  (fkcedemple = pkcedemple)  and   
	(fkcodexcu = pkcodexcu)  and  
	(fkcedemple = '7000' ) 
ORDER BY tdretardos.fkcodexcu, tdretardos.fecha  ;


SELECT pknr,   
	fkcedemple AS "Cédula",   
	nomemple AS "Nombre",
	fkcodexcu AS "Código", 
	dexcusa, 
	tdretardos.fecha, 
	tdretardos.hora
FROM  tdretardos , tmempleados ,  tmexcusas   
WHERE  (fkcedemple = pkcedemple)  and   
	(fkcodexcu = pkcodexcu) 
ORDER BY CAST(fkcedemple AS BIGINT) ASC, tdretardos.fkcodexcu, tdretardos.fecha  ;





----------------------------------------------------------------------------
-- BLOQUE JOIN
----------------------------------------------------------------------------
\echo ' '
\echo ' '
\echo 'Paso 03.02 BLOQUE CONSULTAS JOIN.......................'
-- SELECT ' '  AS paso, pg_sleep(05);


-- CREANDO TABLA XCARGOS
\echo ' '
\echo ' '
\echo 'Creando la tabla XCARGOS.......................'
-- SELECT ' '  AS paso, pg_sleep(05);
CREATE   TABLE    xcargos(
	pkcodcar	SERIAL  primary key   not null,
	dcargo	 varchar(30) 		not null,
	sueldo	 decimal(12,2)  	not null,
	fkcods	 INTEGER	 	not null	 DEFAULT 1,
	foreign  key(fkcods)  references  tmstatus(pkcods) on  update  cascade  on  delete    restrict )    ;

INSERT  INTO  xcargos (dcargo,  sueldo)  VALUES
	('PRESIDENTE' ,	5000000.00),
	('VICE PRESIDENTE',	4500000.00),
	('GERENTE' ,		4000000.00), 
	('SUB-GERENTE' ,	3500000.00),
	('COORDINADOR',	3000000.00),
	('SUPERVISOR', 	2500000.00);  

SELECT pkcodcar,  
	dcargo, 
	to_char( sueldo, '999G999G999D99' ) As "Sueldo"
FROM   xcargos   ;


-- CREACION TABLA XEMPLEADOS
\echo ' '
\echo ' '
\echo 'Creando la tabla XEMPLEADOS.......................'
-- SELECT ' '  AS paso, pg_sleep(05);
CREATE  TABLE   xempleados ( 
	pkcedemple  		varchar(12)   not null PRIMARY KEY,
	nomemple		varchar(40)  not null,
	fecha			date   not null,
	fkcodcar		integer ,
	fkcods  		integer not null DEFAULT 1,
	foreign  key(fkcodcar)  references  xcargos(pkcodcar) on  update  cascade    on  delete  restrict,
	foreign  key(fkcods)  references  tmstatus(pkcods) on  update  cascade    on  delete  restrict) ;

INSERT   INTO  xempleados (pkcedemple,	nomemple,   fecha,  fkcodcar)  VALUES 
	('1000' , 'ROBERTO JAIMES' ,'1978-03-03' , 3),
	('2000' , 'ZILA CONTRERAS' ,'1980-10-05' , 2),
	('3000' , 'MARTHA',		'1996-11-22' , 3),
	('4000' , 'CARLOS', 		'2000-07-15' , 4),
	('5000' , 'MATIAS', 		'2005-09-25' , 4),
	('6000' , 'NATASHA', 	'2007-10-28' , 1),
	('7000' , 'PEGGY CARTER', 	'1999-08-29' , 2),
	('8000' , 'YSA CAPACHO', 	'1993-07-23' , 2),
	('9000' , 'MARIA', 		'2003-07-07' , 4);

INSERT   INTO  xempleados (pkcedemple,  nomemple,   fecha)    VALUES 
	('3001' , 'RITA' , 		'1978-04-03'),
	('3002' , 'JOHANNA' , 	'1980-07-20'),
	('3003' , 'VLADIMIR' , 	'1998-05-22'),
	('3004' , 'ARMANDO' , 	'2007-07-21'),
	('7001' , 'MARIA GIL', 	'2002-04-17'),
	('7002' , 'JAMES' , 		'1997-10-28'),
	('7003' , 'FANNY', 		'1999-08-27'),
	('7004' , 'NATHALY' , 	'1993-07-23'),
	('7005' , 'THALIA' ,		'2003-07-09')   ;

SELECT * FROM xempleados ORDER BY pkcedemple;



-- 3.2.A.- INNER JOIN (INTERIOR)
\echo ' '
\echo ' '
\echo 'Paso 03.02.A: INNER JOIN (INTERIOR) .....'
-- SELECT ' '  AS paso, pg_sleep(02);
-----------------------------------------------------------------
SELECT  *
FROM	    xempleados  AS   Izquierda 
JOIN       xcargos     AS   Derecha 
ON 	    Izquierda.fkcodcar = Derecha.pkcodcar
ORDER BY   Izquierda.pkcedemple ;


SELECT     Izq.pkcedemple, Izq.nomemple, Izq.fecha, Der.dcargo
FROM       xempleados   AS  Izq  
JOIN       xcargos      AS  Der 
ON         Izq.fkcodcar = Der.pkcodcar 
ORDER BY   Izq.pkcedemple ;



-- 3.2.B.- LEFT JOIN (IZQUIERDA)
\echo ' '
\echo ' '
\echo 'Paso 03.02.B: LEFT JOIN (IZQUIERDA) .....'
-- SELECT ' '  AS paso, pg_sleep(02);
-----------------------------------------------------------------
SELECT      Izq.pkcedemple,  Izq.nomemple,  Izq.fecha,  Izq.fkcodcar, Der.dcargo
FROM        xempleados    AS  Izq  
LEFT JOIN   xcargos       AS  Der
ON          Izq.fkcodcar  =  Der.pkcodcar 
ORDER BY    Izq.pkcedemple ;



-- 3.2.C.- RIGHT JOIN (DERECHA)
\echo ' '
\echo ' '
\echo 'Paso 03.02.C: RIGHT JOIN (DERECHA) .....'
-- SELECT ' '  AS paso, pg_sleep(02);
-----------------------------------------------------------------
SELECT       Izq.pkcedemple, Izq.nomemple, Izq.fecha, Izq.fkcodcar, Der.dcargo
FROM         xempleados   AS  Izq  
RIGHT JOIN   xcargos      AS  Der
ON           Izq.fkcodcar = Der.pkcodcar 
ORDER BY     Izq.pkcedemple ;



-- 3.2.D.- FULL JOIN (COMPLETO)
\echo ' '
\echo ' '
\echo 'Paso 03.02.D: FULL JOIN (COMPLETO) .....'
-- SELECT ' '  AS paso, pg_sleep(02);
-----------------------------------------------------------------
SELECT  Izq.pkcedemple, Izq.nomemple, Izq.fecha, Izq.fkcodcar, Der.dcargo
FROM        xempleados   AS  Izq  
FULL JOIN   xcargos      AS  Der
ON          Izq.fkcodcar = Der.pkcodcar 
ORDER BY    Izq.pkcedemple ;



-- CONSULTA PARA PROBAR ......
SELECT izq.pkcedemple,
        izq.nomemple,
        izq.fecha,
        izq.fkcodcar,
        der.dcargo
FROM       xempleados   AS izq
FULL JOIN  xcargos      AS der ON izq.fkcodcar = der.pkcodcar
WHERE      izq.fkcodcar IN (2,4,6)
ORDER BY   izq.fkcodcar;



-- 3.2.E.- JOIN CON VARIAS TABLA
\echo ' '
\echo ' '
\echo 'Paso 03.02.E: JOIN CON VARIA TABLAS .....'
-- SELECT ' '  AS paso, pg_sleep(02);
-----------------------------------------------------------------
SELECT pkcedemple 		AS "Cédula",
	Nomemple   		AS "Nombre", 
	fkcodcar   		AS "Código Cargo",
	xcargos.dcargo	AS "Cargo",
	xempleados.fkcods 	AS "Código Status",
	tmstatus.dstatus 
FROM  	xempleados 
JOIN  	xcargos	ON  xempleados.fkcodcar = xcargos.pkcodcar
JOIN  	tmstatus  	ON  xempleados.fkcods = tmstatus.pkcods ;



SELECT pknr,   
	fkcedemple AS "Cédula",
	fkcodexcu  AS "Código", 
	dexcusa, 
	Izq.fecha, 
	Izq.hora
FROM   tdretardos  AS Izq 
JOIN   tmempleados AS Der1  ON  Izq.fkcedemple = Der1.pkcedemple
JOIN   tmexcusas   AS Der2  ON  Izq.fkcodexcu = Der2.pkcodexcu ;



SELECT pknr,   
	fkcedemple AS "Cédula",   
	nomemple   AS "Nombre",
	fkcodexcu  AS "Código", 
	dexcusa, 
	tdretardos.fecha, 
	tdretardos.hora
FROM  tdretardos , tmempleados ,  tmexcusas   
WHERE  (fkcedemple = pkcedemple)  and   (fkcodexcu = pkcodexcu)  and  (fkcedemple = '7000' ) 
ORDER BY tdretardos.fkcodexcu, tdretardos.fecha  ;



SELECT    pknr,   
	   fkcedemple AS "Cédula",   
	   nomemple   AS "Nombre",
	   fkcodexcu  AS "Código", 
	   dexcusa, 
	   tdretardos.fecha, 
	   tdretardos.hora
FROM      tdretardos  
JOIN      tmempleados    ON  fkcedemple = pkcedemple
JOIN      tmexcusas      ON  fkcodexcu = pkcodexcu 
WHERE     fkcedemple = '7000'  
ORDER BY  tdretardos.fkcodexcu, tdretardos.fecha  ;



SELECT pknr, 
	fkcedemple AS Cedula,  
	nomemple   AS Nombre, 
	fkcodexcu  AS Codigo, 
	dexcusa, 
	tdretardos.fecha, 
	tdretardos.hora
FROM  tdretardos  
INNER JOIN   tmempleados    ON  fkcedemple = pkcedemple
INNER JOIN   tmexcusas      ON  fkcodexcu = pkcodexcu 
WHERE   fkcedemple = '7000'  
ORDER BY tdretardos.fkcodexcu, tdretardos.fecha;



SELECT    pknr,  
	   fkcodexcu         AS   "Código",  
	   dexcusa           AS   "Excusa",
          fkcedemple        AS   "Cédula",  
          nomemple          AS   "Nombre", 
          tdretardos.fecha  AS   "Fecha",      
          tdretardos.hora   AS   "Hora"
FROM      tdretardos  
FULL   JOIN   tmempleados    ON   fkcedemple   =    pkcedemple
FULL   JOIN   tmexcusas      ON   fkcodexcu    =    pkcodexcu 
WHERE         fkcodexcu      IN  (2,     4,    6)
ORDER BY   tdretardos.fkcodexcu,    tdretardos.fkcedemple,    tdretardos.fecha ;





----------------------------------------------------------------------------
-- 04.- BLOQUE VISTAS
----------------------------------------------------------------------------
\echo ' '
\echo ' '
\echo ' '
\echo ' '
\echo 'Paso 04: BLOQUE VISTAS    '
-- SELECT ' '  AS paso, pg_sleep(05);

\echo ' '
\echo ' '
\echo 'Ejemplo Vista 04.00 ---> vretardos00 '
\echo 'ESTA CONSULTA ES IMPORTANTE PARA EL MODULO REPORTE DEL SISTEMA RETARDADOS...'
-- SELECT ' '  AS paso, pg_sleep(02);
-- 
CREATE OR REPLACE VIEW vretardos00 AS
	SELECT pknr, 
		fkcedemple, 
		nomemple, 
		fkcodexcu, 
		dexcusa, 
		ffecha_mes_texto( R.fecha )   As fecha,
		fhora_ampm( R.hora)	AS hora,
		R.fkcods As fkcods,
		dstatus
	FROM tdretardos AS R 
	JOIN tmempleados ON fkcedemple = pkcedemple
	JOIN tmexcusas   ON fkcodexcu = pkcodexcu
	JOIN tmstatus    ON R.fkcods = pkcods
	ORDER BY R.fecha, R.hora ;

SELECT * FROM vretardos00;


\echo ' '
\echo ' '
\echo 'Ejemplo Vista 04.01 ---> vtmcargos '
-- SELECT ' '  AS paso, pg_sleep(02);

-- to_char( Campo_Numérico, ‘999G999G999D99’ )   -----> Formato Númerico

CREATE OR REPLACE VIEW vtmcargos AS
	SELECT pkcodcar, 
		dcargo, 
		to_char( sueldo, '999G999G999D99' ) As "Sueldo", 
		dstatus, 
		fkcods
	FROM tmcargos, tmstatus
	WHERE fkcods = pkcods
	ORDER BY pkcodcar;

select * from vtmcargos;


\echo ' '
\echo ' '
\echo 'Ejemplo Vista 04.02 ---> vretardos02 '
-- SELECT ' '  AS paso, pg_sleep(02)
CREATE OR REPLACE VIEW vretardos02 AS
	SELECT    fkcedemple AS Cedula ,
		   nomemple 	AS Nombre,
		   E.fecha 	AS Fecha_Nac,
		   (EXTRACT( YEAR FROM Now())  -  (EXTRACT( YEAR FROM E.fecha))) As Edad,
		   fkcodexcu 	AS Codigo ,
		   dexcusa 	AS Excusa,
		   pknr 	AS No_Retardo,		   
		   R.fecha 	AS Fecha_Retardo
	FROM     tdretardos 	AS R  
	JOIN     tmempleados AS E 	ON fkcedemple = pkcedemple
	JOIN     tmexcusas 		ON fkcodexcu = pkcodexcu
	ORDER BY fkcedemple::BIGINT, fkcodexcu ;

SELECT * FROM  vretardos02;

SELECT * FROM  vretardos02 WHERE edad >= 45;



\echo ' '
\echo ' '
\echo 'Ejemplo Vista 04.03 ---> vretardos03 '
-- SELECT ' '  AS paso, pg_sleep(02);
CREATE OR REPLACE VIEW vretardos03 AS
	SELECT pknr, 
		fkcedemple, 
		nomemple, 
		fkcodexcu, 
		dexcusa, 
		to_char( R.fecha, 'DD/MM/YYYY' ) As Fecha_Retardo, 
		TO_CHAR(hora, 'HH12:MI AM')	AS Hora_Retardo-- Formato Am/Pm   
	FROM tdretardos AS R 
	JOIN tmempleados ON fkcedemple = pkcedemple
	JOIN tmexcusas ON fkcodexcu = pkcodexcu
	WHERE  (R.fecha BETWEEN  '2022-07-01'  and '2022-12-31')
	ORDER BY R.fecha, hora ;

SELECT * FROM vretardos03;


SELECT pknr 		AS "#",
	Fecha_Retardo AS "Fecha",
	Hora_Retardo 	As "Hora",
	fkcodexcu 	AS "Código",
	dexcusa 	AS "Excusa",	
	fkcedemple 	AS "Cédula",
	nomemple 	AS "Nombre"
FROM   vretardos03;


SELECT pknr 		AS "#",
	Fecha_Retardo AS "Fecha",
	Hora_Retardo 	As "Hora",
	fkcodexcu 	AS "Código",
	dexcusa 	AS "Excusa",	
	fkcedemple 	AS "Cédula",
	nomemple 	AS "Nombre"
FROM   vretardos03
WHERE fkcodexcu IN (2,4,6);


SELECT pknr 		AS "#",
	fkcodexcu 	AS "Código",
	Fecha_Retardo AS "Fecha",
	Hora_Retardo 	As "Hora",
	dexcusa 	AS "Excusa",	
	fkcedemple 	AS "Cédula",
	nomemple 	AS "Nombre"
FROM   vretardos03
WHERE (fkcodexcu IN (2,4,6) and fkcedemple IN ('1000', '3000', '7000'))
ORDER BY fkcodexcu, Fecha_Retardo, Hora_Retardo;



\echo ' '
\echo ' '
\echo 'Ejemplo 04.04 Vista ---> vretardos04 '
-- SELECT ' '  AS paso, pg_sleep(02);
CREATE OR REPLACE VIEW vretardos04 AS
	SELECT   pknr, 
		  fkcedemple, 
		  nomemple, 
		  fkcodexcu, 
		  dexcusa, 
		  to_char( R.fecha, 'DD/MM/YYYY' ) AS Fecha_Retardo, 
		  TO_CHAR(hora, 'HH12:MI AM') AS Hora_Retardo-- HH12:MI:SS AM  (Formato Am/Pm)   
	FROM     tdretardos  AS R
	JOIN     tmempleados ON fkcedemple = pkcedemple
	JOIN     tmexcusas ON fkcodexcu = pkcodexcu
	ORDER BY pknr, R.fecha, hora ;

select * from vretardos04;





----------------------------------------------------------------------------
-- 05.- BLOQUE FUNCIONES DEFINIDAS POR EL USUARIO (FDU)
----------------------------------------------------------------------------
\echo ' '
\echo ' '
\echo ' '
\echo ' '
\echo 'Paso 05: BLOQUE FUNCIONES DEFINIDAS POR EL USUARIO (FDU)   '
-- SELECT ' '  AS paso, pg_sleep(05);



\echo ' '
\echo ' '
\echo 'Ejemplo Funcion 05.01 festudio02()'
\echo '        Para determinar si numero x es Deficiente, Perfecto o Abundante'
-- SELECT ' '  AS paso, pg_sleep(02);
-- Función para determinar si un número X es Deficiente, Perfecto o Abundante
CREATE OR REPLACE FUNCTION  festudio02(xnum integer)    RETURNS     text      AS $$ 
DECLARE 
	xsuma    integer := 0;
	xsw      integer := 0;
	i        integer := 0;
	texto    text := 'Mensaje de retorno….';
BEGIN 
	IF xnum <= 0 THEN
		texto:= 'Calculo imposible... Valor Negativo' ;
	ELSE
		FOR   i   IN   1 .. (xnum-1)   BY +1 
		LOOP
			IF mod (  xnum  , i )   =   0   THEN
				xsuma :=   xsuma   +  i ;
				RAISE NOTICE 'Divisor ---> %   Suma ---> %', i, xsuma;
			END IF;
		END LOOP;
		IF  xsuma   <   xnum  THEN
			Texto  := 'El valor ' || CAST(xnum AS text) || ' es Definiente.';
		ELSE
			IF  xsuma   =   xnum  THEN
				texto :=  'El valor ' || CAST(xnum AS text) || ' es Perfecto.';
			ELSE
				texto :=  'El valor ' || CAST(xnum AS text) || ' es Abundante.';
			END IF;  
		END IF;
	END IF;
   
	RETURN   texto;
END; 
$$ LANGUAGE   plpgsql; 

SELECT   festudio02(10);
SELECT   festudio02(6);
SELECT   festudio02(12);



\echo ' '
\echo ' '
\echo 'Ejemplo Funcion 05.02 fhora_ampm()'
\echo '        Para retornar la hora en formato AM/PM.....'
SELECT ' '  AS paso, pg_sleep(02);

-- Función que retorna la hora en formato AM/PM
CREATE OR REPLACE FUNCTION  fhora_ampm(xhora time)    RETURNS     text      AS $$ 
DECLARE 
	zhora         integer  := 0;
	yhora         text     := ' ';

	zmin          integer  := 0;
	ymin          text     := ' ';

	yindicativo   text     := ' ';
	xhora_ampm    text     := ' ';
BEGIN 
	SELECT EXTRACT(Hour FROM xhora) INTO zhora;   -- El valor que retorna es integer
	SELECT EXTRACT(Minute FROM  xhora) INTO zmin; -- El valor que retorna es integer

	IF zhora <12 THEN
		yindicativo :='Am';

	ELSE
		yindicativo :='Pm';
		IF zhora = 12 THEN
			zhora := 12;
		ELSE
			zhora := zhora - 12;
		END IF;		
	END IF;

	-- Conversion de Integer a string
	-- 	CAST(mi_numero AS VARCHAR(10))
	--	mi_numero INTEGER := 12345;
    	--	mi_cadena TEXT;
	--		mi_cadena := mi_numero::TEXT;
    	-- 		mi_cadena contendrá '12345

	IF zhora <=9 THEN
		yhora := '0' || CAST(zhora AS varchar(01));
	ELSE
		yhora :=  CAST(zhora AS varchar(02));
	END IF;


	IF zmin <= 9 THEN
		ymin := '0' || CAST(zmin AS varchar(01));
	ELSE
		ymin := CAST(zmin AS varchar(02));
	END IF;


	xhora_ampm := yhora || ':' || ymin || ' ' || yindicativo;
	   
	RETURN   xhora_ampm;
END; 
$$ LANGUAGE   plpgsql;

 --Se envia lo hora actual a la función usando conversión explicita
SELECT fhora_ampm(now()::time);
SELECT fhora_ampm(current_timestamp::time);
SELECT fhora_ampm(current_time::time);
SELECT fhora_ampm('17:21:00');



\echo ' '
\echo ' '
\echo 'Ejemplo Funcion 05.03 fhora_server_ampm() '
\echo '        Para retorna la hora en actua del servidor en formato AM/PM.....'
-- SELECT ' '  AS paso, pg_sleep(02);
-- Función para obtener la hora actual del servidor en formato texto HH:MM Am/Pm
CREATE OR REPLACE FUNCTION  fhora_server_ampm()    RETURNS     text      AS $$ 
DECLARE 
	hora_actual_sis       time;
	hora_texto_ampm       text := ' ';
BEGIN 
	SELECT current_time INTO hora_actual_sis;   -- retorna la hora actual
	-- SELECT current_date INTO xfecha;            retorna la Fecha actual
	-- SELECT current_timestamp INTO xfecha;       retorna la Fecha-Hora actual 
	-- SELECT NOW() INTO xfecha;                   retorna la Fecha-Hora actual

  	hora_texto_AMPM := fhora_ampm(hora_actual_sis);
	RETURN   hora_texto_AMPM;
END; 
$$ LANGUAGE   plpgsql; 

SELECT fhora_server_ampm();




\echo ' '
\echo ' '
\echo 'Ejemplo Funcion 05.04 ffecha_mes_texto()' 
\echo '        Para retorna la fecha en formato DD/Texto_Mes/AAAA.....'
-- SELECT ' '  AS paso, pg_sleep(02);
-- Función que retorna la fecha actual del sistema en formato DD/Texto_Mes/AAAA
CREATE OR REPLACE FUNCTION  ffecha_mes_texto(xfecha date)   RETURNS   text  AS $$ 
DECLARE 
	xdia             integer := 0;
	ydia             text := ' ';
	xmes             integer := 0;
	ymes             text := ' ';
	xyear            integer := 0;
	fecha_texto_mes  text := ' ';

	-- NOTA: los arreglos inician en posición 1
	array_meses varchar(05)[]:= ARRAY['Ene', 'Feb', 'Marz', 'Abr', 
						'May', 'Jun', 'Jul', 'Agost', 'Sept', 
						'Oct', 'Nov', 'Dic'];
BEGIN 
	SELECT EXTRACT(DAY FROM xfecha) INTO xdia;   -- El valor que retorna es integer
	SELECT EXTRACT(MONTH FROM xfecha) INTO xmes; -- El valor que retorna es integer
	SELECT EXTRACT(YEAR FROM xfecha) INTO xyear; -- El valor que retorna es integer

	-- Conversion de Integer a string
	-- 	CAST(mi_numero AS VARCHAR(10))
	--	mi_numero INTEGER := 12345;
    	--	mi_cadena TEXT;
	--		mi_cadena := mi_numero::TEXT;
    	-- 		mi_cadena contendrá '12345

	IF xdia <=9 THEN
		ydia := '0' || CAST(xdia AS varchar(01));
	ELSE
		ydia := CAST(xdia AS varchar(02));
	END IF;

	FOR i IN 1 .. 12 BY +1
	LOOP
		IF xmes = i THEN
			ymes := array_meses[i];
		END IF;
	END LOOP ;

	fecha_texto_mes := ydia || '/' || ymes || '/' || CAST(xyear AS varchar(04));
	   
	RETURN   fecha_texto_mes;
END; 
$$ LANGUAGE   plpgsql;

 --Se envia lo hora actual a la función usando conversión explicita
SELECT ffecha_mes_texto(now()::date);
SELECT ffecha_mes_texto(current_timestamp::date);
SELECT ffecha_mes_texto(current_date::date);
SELECT ffecha_mes_texto('1967/11/22');



\echo ' '
\echo ' '
\echo 'Ejemplo Funcion 05.05 ffecha_server_mes_texto()'
\echo '        Pata retorna la fecha actual del servidor en formato DD/Texto_mes/AAAA.....'
-- SELECT ' '  AS paso, pg_sleep(02);
-- Función para obtener la fecha actual del servidor en formato texto DD/Texto_Mes/AAAA
CREATE OR REPLACE FUNCTION  ffecha_server_mes_texto()    RETURNS     text      AS $$ 
DECLARE 
	fecha_actual_sis      date;
	fecha_texto_mes       text := ' ';
BEGIN 
	SELECT current_date INTO fecha_actual_sis;  -- retorna la fecha actual
	-- SELECT current_time INTO xtime;             retorna la hora actual
	-- SELECT current_timestamp INTO xfecha;       retorna la Fecha-Hora actual 
	-- SELECT NOW() INTO xfecha;                   retorna la Fecha-Hora actual

  	fecha_texto_mes := ffecha_mes_texto(fecha_actual_sis);
	RETURN   fecha_texto_mes;
END; 
$$ LANGUAGE   plpgsql; 

SELECT ffecha_server_mes_texto();



\echo ' '
\echo ' '
\echo 'Ejemplo Funcion 05.06 ffecha_texto()'
\echo '        Para retorna la fecha actual del servidor en'
\echo '        Formato Lunes..., DD de Mes de AAAA.'
-- SELECT ' '  AS paso, pg_sleep(02);
-- Función que retorna la fecha en formato Lunes..., DD de Mes de AAAA.
CREATE OR REPLACE FUNCTION    ffecha_texto(xfecha_sis date)    RETURNS     text      AS $$ 
DECLARE 
	xdia         integer := 0;
	ydia         text := ' ';
	xmes         integer := 0;
	ymes         text := ' ';
	xyear        integer := 0;
	xdia_semana  integer := 0;
	ydia_semana  text := ' ';
	fecha_texto  text := ' ';

	-- NOTA: los arreglos inician en posición 1
	array_meses varchar(05)[]:= ARRAY['Ene', 'Feb', 'Marz', 'Abr', 'May', 
						'Jun', 'Jul', 'Agost', 'Sept', 
						'Oct', 'Nov', 'Dic'];

	array_dia_semana varchar(10)[]:=ARRAY['Domingo', 'Lunes', 'Martes', 
						'Miercoles', 'Jueves', 'Viernes', 
						'Sabado'];
BEGIN 
	-- El valor que retorna es integer
	SELECT EXTRACT(DAY FROM xfecha_sis) INTO xdia; 

	-- El valor que retorna es integer
	SELECT EXTRACT(MONTH FROM xfecha_sis) INTO xmes; 

	-- El valor que retorna es integer
	SELECT EXTRACT(YEAR FROM xfecha_sis) INTO xyear; 

	-- El valor que retorna es integer. Dom(0), Lun(1)...
	SELECT EXTRACT(Dow FROM xfecha_sis) INTO xdia_semana; 



	-- Conversion de Integer a string
	-- 	CAST(mi_numero AS VARCHAR(10))
	--	mi_numero INTEGER := 12345;
    	--	mi_cadena TEXT;
	--		mi_cadena := mi_numero::TEXT;
    	-- 		mi_cadena contendrá '12345'


	IF xdia <=9 THEN
		ydia := '0' || CAST(xdia AS varchar(01));
	ELSE
		ydia := CAST(xdia AS varchar(02));
	END IF;

	FOR i IN 1 .. 12 BY +1
	LOOP
		IF xmes = i THEN
			ymes := array_meses[i];
		END IF;
	END LOOP ;

	FOR i IN 1 .. 7 BY +1
	LOOP
		IF xdia_semana + 1 = i THEN
			ydia_semana := array_dia_semana[i];
		END IF;
	END LOOP ;

	fecha_texto := ydia_semana || ', ' ||ydia || '/' || ymes || '/' || CAST(xyear AS varchar(04));
	   
	RETURN   fecha_texto;
END; 
$$ LANGUAGE   plpgsql;


SELECT ffecha_texto(now()::date);
SELECT ffecha_texto(current_timestamp::date);
SELECT ffecha_texto(current_date::date);
SELECT ffecha_texto('1967/11/22');



\echo ' '
\echo ' '
\echo 'Ejemplo Funcion 05.07 ffecha_server_texto()'
\echo '        Para retorna la fecha actual  del servidor en'
\echo '        formato Lunes..., DD de Mes de AAAA......'
-- SELECT ' '  AS paso, pg_sleep(02);
-- Función para obtener la fecha actual del servidor en formato texto DD/Texto_Mes/AAAA
CREATE OR REPLACE FUNCTION  ffecha_server_texto()  RETURNS     text      AS $$ 
DECLARE 
	fecha_actual_sis      date;
	fecha_texto       text := ' ';
BEGIN 
	SELECT current_date INTO fecha_actual_sis;  -- retorna la fecha actual
	-- SELECT current_time INTO xtime;             retorna la hora actual
	-- SELECT current_timestamp INTO xfecha;       retorna la Fecha-Hora actual 
	-- SELECT NOW() INTO xfecha;                   retorna la Fecha-Hora actual

  	fecha_texto := ffecha_texto(fecha_actual_sis);
	RETURN   fecha_texto;
END; 
$$ LANGUAGE   plpgsql; 

SELECT ffecha_server_texto();





----------------------------------------------------------------------------
-- 06.- BLOQUE VISTAS & FUNCIONES DEFINIDAS POR EL USUARIO (FDU) 
----------------------------------------------------------------------------
\echo ' '
\echo ' '
\echo ' '
\echo ' '
\echo 'Paso 06: BLOQUE VISTAS & FUNCIONES DEFINIDAS POR EL USUARIO (FDU) '
-- SELECT ' '  AS paso, pg_sleep(05);


\echo ' '
\echo ' '
\echo 'Ejemplo 06.01 Vista  &  Funciones  ---> v_f_retardos01 '
-- SELECT ' '  AS paso, pg_sleep(02);

CREATE OR REPLACE VIEW v_f_retardos01 AS
	SELECT pknr, 
		fkcedemple, 
		nomemple, 
		fkcodexcu, 
		dexcusa, 
		ffecha_mes_texto( R.fecha) AS "Fecha Retardo", 
		fhora_ampm(hora) AS "Hora Retardo", 
		R.fkcods,
		dstatus  
	FROM   tdretardos AS R 
	JOIN   tmempleados ON   fkcedemple = pkcedemple
	JOIN   tmexcusas   ON   fkcodexcu = pkcodexcu
	JOIN   tmstatus    ON   pkcods = R.fkcods
	ORDER BY pknr;

select * from v_f_retardos01;



